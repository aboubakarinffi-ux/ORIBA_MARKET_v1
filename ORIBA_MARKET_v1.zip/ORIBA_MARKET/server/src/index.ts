import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';
import { randomUUID } from 'node:crypto';

const app = express();
const prisma = new PrismaClient();
const port = Number(process.env.PORT || 4000);
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '100kb' }));
app.get('/api/health', (_req,res)=>res.json({ok:true,service:'ORIBA MARKET API'}));
app.get('/api/products', async (req,res,next)=>{
 try {
  const category = typeof req.query.category === 'string' ? req.query.category : undefined;
  const search = typeof req.query.search === 'string' ? req.query.search : undefined;
  const products = await prisma.product.findMany({where:{status:'ACTIVE',...(category?{category}:{}),...(search?{OR:[{name:{contains:search,mode:'insensitive'}},{description:{contains:search,mode:'insensitive'}}]}:{})},include:{seller:{select:{storeName:true,city:true}}},take:60,orderBy:{createdAt:'desc'}});
  res.json(products);
 } catch(e){next(e)}
});
const orderSchema = z.object({customer:z.object({name:z.string().trim().min(2).max(120),phone:z.string().trim().min(5).max(30),city:z.string().trim().min(2).max(100),address:z.string().trim().min(3).max(300)}),items:z.array(z.object({productId:z.number().int().positive(),quantity:z.number().int().min(1).max(50),unitPrice:z.number().int().positive()})).min(1).max(30)});
app.post('/api/orders', async (req,res,next)=>{
 try {
  const parsed=orderSchema.safeParse(req.body);
  if(!parsed.success){res.status(400).json({error:'Données invalides',details:parsed.error.flatten()});return;}
  // This MVP uses the supplied catalogue IDs only for demo order requests.
  // Production must resolve product prices and stock from the database, never trust client prices.
  const totalXof=parsed.data.items.reduce((sum,item)=>sum+item.quantity*item.unitPrice,0);
  const orderNumber='ORI-'+randomUUID().slice(0,8).toUpperCase();
  res.status(201).json({orderNumber,totalXof,status:'REQUESTED',paymentStatus:'UNPAID',message:'Demande reçue; aucun paiement effectué.'});
 } catch(e){next(e)}
});
app.use((err:unknown,_req:express.Request,res:express.Response,_next:express.NextFunction)=>{console.error(err);res.status(500).json({error:'Erreur interne du serveur'});});
app.listen(port,()=>console.log(`ORIBA MARKET API listening on http://localhost:${port}`));
process.on('SIGINT',async()=>{await prisma.$disconnect();process.exit(0)});
