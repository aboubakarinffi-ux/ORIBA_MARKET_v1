export type Product = { id:number; name:string; category:string; price:number; seller:string; location:string; emoji:string; description:string; badge?:string };
export const products: Product[] = [
 {id:1,name:'Riz local — sac de 25 kg',category:'Alimentation',price:14500,seller:'Marché Sahel',location:'Niamey',emoji:'🌾',description:'Riz local conditionné en sac de 25 kg. Vérifiez la disponibilité et le prix final auprès du vendeur.',badge:'Populaire'},
 {id:2,name:'Huile végétale — 5 litres',category:'Alimentation',price:6200,seller:'Épicerie Centrale',location:'Niamey',emoji:'🫗',description:'Huile végétale alimentaire en bidon de 5 litres.'},
 {id:3,name:'Smartphone Android',category:'Électronique',price:78500,seller:'Tech Niger',location:'Maradi',emoji:'📱',description:'Smartphone Android. Modèle, capacité et garantie à confirmer avec le vendeur.',badge:'Nouveau'},
 {id:4,name:'Ciment — sac de 50 kg',category:'Construction',price:5500,seller:'BTP Distribution',location:'Dosso',emoji:'🧱',description:'Sac de ciment de 50 kg. Livraison à convenir avec le vendeur.'},
 {id:5,name:'Chaussures de sport',category:'Mode',price:12000,seller:'Style Shop',location:'Zinder',emoji:'👟',description:'Chaussures de sport disponibles en plusieurs tailles selon le stock.'},
 {id:6,name:'Pièces détachées moto',category:'Automobile',price:9500,seller:'Garage Express',location:'Tahoua',emoji:'🏍️',description:'Pièces détachées pour motos. Compatibilité à confirmer avant commande.'},
 {id:7,name:'Tomates fraîches — panier',category:'Agriculture',price:3000,seller:'Coopérative Verte',location:'Tillabéri',emoji:'🍅',description:'Tomates fraîches issues de producteurs locaux.'},
 {id:8,name:'Réfrigérateur',category:'Maison',price:185000,seller:'Maison Moderne',location:'Niamey',emoji:'🧊',description:'Réfrigérateur domestique. Capacité et garantie à confirmer auprès du vendeur.'},
];
export const categories = ['Tout','Alimentation','Électronique','Construction','Mode','Automobile','Agriculture','Maison'];
