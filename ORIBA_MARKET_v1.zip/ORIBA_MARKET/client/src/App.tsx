import { useMemo, useState } from 'react';
import { Search, ShoppingBag, Menu, X, Plus, Minus, Trash2, MapPin, ShieldCheck, Truck, Store, ArrowRight, PackageCheck } from 'lucide-react';
import { products, categories, type Product } from './data';

type CartLine = { product: Product; qty: number };
const money = (n:number) => new Intl.NumberFormat('fr-FR').format(n) + ' FCFA';

export default function App() {
 const [query,setQuery] = useState('');
 const [category,setCategory] = useState('Tout');
 const [cart,setCart] = useState<CartLine[]>([]);
 const [selected,setSelected] = useState<Product|null>(null);
 const [cartOpen,setCartOpen] = useState(false);
 const [notice,setNotice] = useState('');
 const [buyer,setBuyer] = useState({name:'',phone:'',city:'Niamey',address:''});
 const [checkout,setCheckout] = useState(false);
 const visible = useMemo(()=>products.filter(p=>(category==='Tout'||p.category===category) && `${p.name} ${p.category} ${p.seller} ${p.location}`.toLowerCase().includes(query.toLowerCase())),[query,category]);
 const count = cart.reduce((s,l)=>s+l.qty,0);
 const total = cart.reduce((s,l)=>s+l.qty*l.product.price,0);
 const add = (p:Product)=>{setCart(old=>{const found=old.find(l=>l.product.id===p.id);return found?old.map(l=>l.product.id===p.id?{...l,qty:l.qty+1}:l):[...old,{product:p,qty:1}]});setNotice('Produit ajouté au panier');setCartOpen(true);};
 const changeQty=(id:number,delta:number)=>setCart(old=>old.map(l=>l.product.id===id?{...l,qty:l.qty+delta}:l).filter(l=>l.qty>0));
 async function submitOrder(){
  if(!buyer.name.trim()||!buyer.phone.trim()||!buyer.address.trim()){setNotice('Veuillez remplir votre nom, téléphone et adresse.');return;}
  try { const res=await fetch('http://localhost:4000/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:buyer,items:cart.map(l=>({productId:l.product.id,quantity:l.qty,unitPrice:l.product.price}))})});
   if(!res.ok) throw new Error('API indisponible'); const data=await res.json(); setNotice(`Demande de commande ${data.orderNumber} enregistrée. Aucun paiement n’a été effectué.`); setCart([]);setCheckout(false);setCartOpen(false);
  } catch { setNotice('Le serveur API ne répond pas. Démarrez le serveur ORIBA MARKET puis réessayez.'); }
 }
 return <div className="app">
  <div className="topline">ORIBA HOLDING <span>Une place de marché pour tous vos commerces</span><span className="topright">Niger · Afrique · International</span></div>
  <header className="header"><a className="brand" href="#home"><span className="brandmark">O</span><span>ORIBA <b>MARKET</b><small>BY ORIBA HOLDING</small></span></a><div className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Rechercher un produit, une boutique, une catégorie..."/><button onClick={()=>setCategory('Tout')}>Rechercher</button></div><button className="cartbtn" onClick={()=>setCartOpen(true)}><ShoppingBag size={20}/><span>Panier</span><b>{count}</b></button></header>
  <nav className="nav"><a href="#home">Accueil</a><a href="#catalogue">Boutique</a><a href="#how">Comment ça marche</a><a href="#sell">Vendre sur ORIBA</a><a href="#footer">Contact</a><button className="mobilemenu" onClick={()=>setCartOpen(true)}><Menu/></button></nav>
  <main id="home">
   <section className="hero"><div className="hero-copy"><div className="eyebrow">LE MARCHÉ, SANS FRONTIÈRES</div><h1>Tous vos commerces.<br/><em>Un seul marché.</em></h1><p>Découvrez des produits, comparez les offres et contactez des vendeurs. ORIBA MARKET rassemble les commerces et les clients sur une seule plateforme.</p><a className="primary" href="#catalogue">Explorer le marché <ArrowRight size={17}/></a><div className="hero-points"><span><ShieldCheck/> Achats encadrés</span><span><Truck/> Livraison à organiser</span><span><Store/> Vendeurs multiples</span></div></div><div className="hero-art"><div className="orb orb1">🛍️</div><div className="orb orb2">📦</div><div className="orb orb3">🌍</div><div className="hero-card"><div className="hero-card-icon">🧺</div><b>Le commerce évolue.</b><span>Votre marché est ici.</span><div className="mini-bars"><i/><i/><i/><i/><i/><i/><i/></div></div></div></section>
   <section className="trust"><div><strong>01</strong><span>Produits variés</span></div><div><strong>02</strong><span>Commerçants locaux</span></div><div><strong>03</strong><span>Commande simplifiée</span></div><div><strong>04</strong><span>Marché évolutif</span></div></section>
   <section id="catalogue" className="catalog"><div className="section-head"><div><div className="eyebrow">DÉCOUVRIR</div><h2>Le marché ORIBA</h2><p>Une sélection de démonstration — les vendeurs réels ajouteront leurs produits.</p></div><span className="resultcount">{visible.length} produits affichés</span></div>
    <div className="categories">{categories.map(c=><button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div>
    <div className="products">{visible.map(p=><article className="product" key={p.id}><button className="product-image" onClick={()=>setSelected(p)}><span>{p.emoji}</span>{p.badge&&<i>{p.badge}</i>}</button><div className="product-info"><small>{p.category} · {p.location}</small><h3>{p.name}</h3><p className="seller">Vendu par {p.seller}</p><div className="product-bottom"><b>{money(p.price)}</b><button aria-label="Ajouter au panier" onClick={()=>add(p)}><Plus size={18}/></button></div></div></article>)}</div>
    {visible.length===0&&<div className="empty">Aucun produit trouvé. Essayez une autre recherche.</div>}
   </section>
   <section className="sell" id="sell"><div><div className="eyebrow">VOUS ÊTES COMMERÇANT ?</div><h2>Développez votre activité avec ORIBA.</h2><p>Préparez votre boutique, présentez vos produits et touchez de nouveaux clients. L’inscription des vendeurs sera activée après la mise en place de la vérification.</p></div><div className="sell-side"><Store size={34}/><b>Votre boutique mérite<br/>une plus grande vitrine.</b><span>ORIBA MARKET · ORIBA HOLDING</span></div></section>
   <section id="how" className="how"><div className="eyebrow">SIMPLE ET CLAIR</div><h2>Comment ça marche</h2><div className="steps"><div><b>1</b><h3>Découvrez</h3><p>Recherchez des produits et parcourez les catégories.</p></div><div><b>2</b><h3>Ajoutez au panier</h3><p>Choisissez les articles et vérifiez votre commande.</p></div><div><b>3</b><h3>Envoyez la demande</h3><p>Le vendeur confirme disponibilité, livraison et modalités de paiement.</p></div></div></section>
  </main>
  <footer id="footer"><div className="brand footerbrand"><span className="brandmark">O</span><span>ORIBA <b>MARKET</b><small>BY ORIBA HOLDING</small></span></div><p>La place de marché multi-commerces.</p><small>© {new Date().getFullYear()} ORIBA MARKET. Tous droits réservés. Version de développement.</small></footer>
  {notice&&<div className="toast" role="status">{notice}<button onClick={()=>setNotice('')}><X size={16}/></button></div>}
  {selected&&<div className="overlay" onClick={()=>setSelected(null)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}><X/></button><div className="detail-emoji">{selected.emoji}</div><small>{selected.category} · {selected.location}</small><h2>{selected.name}</h2><p>{selected.description}</p><b className="detail-price">{money(selected.price)}</b><p className="seller">Vendeur : {selected.seller}</p><button className="primary full" onClick={()=>{add(selected);setSelected(null)}}>Ajouter au panier <ShoppingBag size={17}/></button></div></div>}
  {cartOpen&&<div className="overlay" onClick={()=>{setCartOpen(false);setCheckout(false)}}><aside className="drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><h2>{checkout?'Finaliser la demande':'Votre panier'}</h2><button className="close" onClick={()=>{setCartOpen(false);setCheckout(false)}}><X/></button></div>
   {!checkout?<>{cart.length===0?<div className="empty"><ShoppingBag size={35}/><p>Votre panier est vide.</p></div>:<><div className="cartlines">{cart.map(l=><div className="cartline" key={l.product.id}><span>{l.product.emoji}</span><div className="lineinfo"><b>{l.product.name}</b><small>{money(l.product.price)}</small><div className="qty"><button onClick={()=>changeQty(l.product.id,-1)}><Minus size={13}/></button>{l.qty}<button onClick={()=>changeQty(l.product.id,1)}><Plus size={13}/></button><button className="remove" onClick={()=>setCart(old=>old.filter(x=>x.product.id!==l.product.id))}><Trash2 size={14}/></button></div></div></div>)}</div><div className="cart-total"><span>Total indicatif</span><b>{money(total)}</b></div><p className="disclaimer">Le total est indicatif. Disponibilité, transport et paiement seront confirmés par le vendeur.</p><button className="primary full" onClick={()=>setCheckout(true)}>Continuer <ArrowRight size={17}/></button></>}</>:<div className="checkout"><label>Nom complet<input value={buyer.name} onChange={e=>setBuyer({...buyer,name:e.target.value})} placeholder="Votre nom"/></label><label>Téléphone<input value={buyer.phone} onChange={e=>setBuyer({...buyer,phone:e.target.value})} placeholder="Numéro de téléphone"/></label><label>Ville<input value={buyer.city} onChange={e=>setBuyer({...buyer,city:e.target.value})}/></label><label>Adresse / quartier<textarea value={buyer.address} onChange={e=>setBuyer({...buyer,address:e.target.value})} placeholder="Votre adresse"/></label><div className="cart-total"><span>Total indicatif</span><b>{money(total)}</b></div><p className="disclaimer">Cette étape envoie une demande de commande. Elle ne prélève aucun argent et ne confirme aucun paiement.</p><button className="primary full" onClick={submitOrder}>Envoyer la demande <PackageCheck size={17}/></button><button className="back" onClick={()=>setCheckout(false)}>Retour au panier</button></div>}
  </aside></div>}
 </div>;
}
