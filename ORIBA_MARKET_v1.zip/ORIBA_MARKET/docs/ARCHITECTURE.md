# Architecture

- `client`: React + TypeScript single-page storefront.
- `server`: Express REST API.
- `server/prisma/schema.prisma`: PostgreSQL data model.
- Browser calls API at `http://localhost:4000` for order requests.

## Trust boundaries
The browser is untrusted. In production, the server must authenticate users, authorize every seller/admin action, derive prices and stock from the database, and create orders transactionally. Never accept a client-submitted price as authoritative. Payment confirmation must come from a verified provider webhook, not from the browser.
