# ORIBA MARKET — launch checklist

- [ ] Confirm legal entity, marketplace operator and countries served.
- [ ] Replace sample catalogue with real seller-approved inventory.
- [ ] Implement authentication, email/phone verification and account recovery.
- [ ] Implement seller/company verification and admin review workflows.
- [ ] Enforce authorization and server-side validation on every endpoint.
- [ ] Resolve product price and stock from database during order creation.
- [ ] Add payment provider sandbox integration, then certification and live credentials.
- [ ] Add delivery contracts, shipping status and proof of delivery.
- [ ] Add terms, privacy policy, refunds, returns and dispute handling.
- [ ] Add automated tests, security review, backups and monitoring.
- [ ] Deploy behind HTTPS with managed secrets and restricted database access.
- [ ] Load test and test Android/mobile browsers.
